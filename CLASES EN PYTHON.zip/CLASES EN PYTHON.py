import sys

p=input("¿QUE ESTADO BUSCAS?")


class Coahuila:
    PRIMERO = "CASOS CONFIRMADOS: 19,889"
    SEGUNDO = "RECUPERADOS: 12,094" 
    TERCERO = "FALLECIDOS: 3,597"
    CUARTO = "HOSPITALIZADOS: 680" 
    QUINTO = "SOSPECHOSOS: 1,564 \n"

casos_covid = Coahuila()
print("CASOS DE COVID EN COAHUILA")
print(casos_covid.PRIMERO)
print(casos_covid.SEGUNDO)
print(casos_covid.TERCERO)
print(casos_covid.CUARTO)
print(casos_covid.QUINTO)


sys.exit()


p=input("¿QUE ESTADO BUSCAS?")


class Sonora:
    PRIMERO = "CASOS CONFIRMADOS: "
    SEGUNDO = "RECUPERADOS: 34,065" 
    TERCERO = "FALLECIDOS: 19,338"
    CUARTO = "HOSPITALIZADOS: 2,928" 
    QUINTO = "SOSPECHOSOS: 2,381 \n"

    
casos_covid = Sonora()
print("CASOS DE COVID EN SONORA")
print(casos_covid.PRIMERO)
print(casos_covid.SEGUNDO)
print(casos_covid.TERCERO)
print(casos_covid.CUARTO)
print(casos_covid.QUINTO)

sys.exit()

p=input("¿QUE ESTADO BUSCAS?")


class Yucatan:
    PRIMERO = "CASOS CONFIRMADOS: "
    SEGUNDO = "RECUPERADOS: 42,904" 
    TERCERO = "FALLECIDOS: 2,338"
    CUARTO = "HOSPITALIZADOS: 5,328" 
    QUINTO = "SOSPECHOSOS: 715 \n"

    
casos_covid = Yucatan()
print("CASOS DE COVID EN YUCATAN")
print(casos_covid.PRIMERO)
print(casos_covid.SEGUNDO)
print(casos_covid.TERCERO)
print(casos_covid.CUARTO)
print(casos_covid.QUINTO)

sys.exit()

p=input("¿QUE ESTADO BUSCAS?\n")


class Guerrero:
    PRIMERO = "CASOS CONFIRMADOS: 19,834"
    SEGUNDO = "RECUPERADOS: 14,734" 
    TERCERO = "FALLECIDOS: 1,977"
    CUARTO = "HOSPITALIZADOS: 800" 
    QUINTO = "SOSPECHOSOS: 775 \n"

    
casos_covid = Guerrero()
print("CASOS DE COVID EN GUERRERO")
print(casos_covid.PRIMERO)
print(casos_covid.SEGUNDO)
print(casos_covid.TERCERO)
print(casos_covid.CUARTO)
print(casos_covid.QUINTO)





